package model;

public class Score {
    public String studentId;
    public String courseId;
    public double score;

    public Score(String studentId,String courseId,double score){
        this.studentId=studentId;
        this.courseId=courseId;
        this.score=score;
    }
}
