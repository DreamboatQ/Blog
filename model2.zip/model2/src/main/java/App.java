import gui.MainFrame;
import service.ScoreService;

import javax.swing.*;

public class App {
    public static void main(String[] args) {
        // 初始化服务
        ScoreService service = ScoreService.getInstance();

        // 创建主窗口
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        });
    }
}
