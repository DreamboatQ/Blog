package service;

import model.Student;
import model.Course;
import model.Score;

import java.io.*;
import java.util.*;

public class ScoreService {
    private static ScoreService instance = new ScoreService(); // 🔹 单例对象
    public ScoreService service;

    public static ScoreService getInstance() {
        return instance;
    }

    public List<Student> students = new ArrayList<>();
    public List<Course> courses = new ArrayList<>();
    public List<Score> scores = new ArrayList<>();

    private final String studentFile = "students.txt";
    private final String courseFile = "courses.txt";
    private final String scoreFile = "scores.txt";

    public ScoreService() {
        loadData();
    }

    public void addStudent(String id, String name) {
        students.add(new Student(id, name));
    }

    public void addCourse(String id, String name) {
        courses.add(new Course(id, name));
    }

    public void addScore(String studentId, String courseId, double score) {
        scores.add(new Score(studentId, courseId, score));
        if (score < 60) {
            System.out.println("警告：" + studentId + " 某课程分数低于 60 分！");
        }
    }

    public void printAllScores() {
        for (Score score : scores) {
            String studentName = students.stream()
                    .filter(st -> st.id.equals(score.studentId))
                    .findFirst().map(st -> st.name).orElse("未知学生");

            String courseName = courses.stream()
                    .filter(c -> c.id.equals(score.courseId))
                    .findFirst().map(c -> c.name).orElse("未知课程");

            System.out.println(studentName + " " + courseName + " " + score.score);
        }
    }

    public void printAverageScores() {
        System.out.println("每位学生平均分统计");
        for (Student student : students) {
            double total = 0;
            int count = 0;

            for (Score score : scores) {
                if (score.studentId.equals(student.id)) {
                    total += score.score;
                    count++;
                }
            }

            if (count == 0) {
                System.out.println(student.name + " 暂无成绩记录");
            } else {
                double avg = total / count;
                System.out.printf("%s: 平均分 %.2f\n", student.name, avg);
            }
        }
    }

    public Map<String, Double> getAverageMap() {
        Map<String, Double> result = new HashMap<>();
        for (Student student : students) {
            double total = 0;
            int count = 0;
            for (Score score : scores) {
                if (score.studentId.equals(student.id)) {
                    total += score.score;
                    count++;
                }
            }
            double avg = (count == 0) ? 0 : total / count;
            result.put(student.name, avg);
        }
        return result;
    }

    public void saveAll() {
        try {
            saveStudents();
            saveCourses();
            saveScores();
        } catch (IOException e) {
            System.out.println("保存数据失败：" + e.getMessage());
        }
    }

    private void saveStudents() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(studentFile))) {
            for (Student student : students) {
                writer.write(student.id + "," + student.name);
                writer.newLine();
            }
        }
    }

    private void saveCourses() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(courseFile))) {
            for (Course course : courses) {
                writer.write(course.id + "," + course.name);
                writer.newLine();
            }
        }
    }

    private void saveScores() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(scoreFile))) {
            for (Score score : scores) {
                writer.write(score.studentId + "," + score.courseId + "," + score.score);
                writer.newLine();
            }
        }
    }

    private void loadData() {
        loadStudents();
        loadCourses();
        loadScores();
    }

    private void loadStudents() {
        File file = new File(studentFile);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",", 2);
                if (parts.length == 2) {
                    students.add(new Student(parts[0], parts[1]));
                }
            }
        } catch (Exception e) {
            System.out.println("加载学生信息失败：" + e.getMessage());
        }
    }

    private void loadCourses() {
        File file = new File(courseFile);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",", 2);
                if (parts.length == 2) {
                    courses.add(new Course(parts[0], parts[1]));
                }
            }
        } catch (Exception e) {
            System.out.println("加载课程信息失败：" + e.getMessage());
        }
    }
    // 在 ScoreService 类中添加
    public String getStudentName(String studentId) {
        return students.stream()
                .filter(s -> s.id.equals(studentId))
                .findFirst()
                .map(s -> s.name)
                .orElse("未知学生");
    }

    public String getCourseName(String courseId) {
        return courses.stream()
                .filter(c -> c.id.equals(courseId))
                .findFirst()
                .map(c -> c.name)
                .orElse("未知课程");
    }

    private void loadScores() {
        File file = new File(scoreFile);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",", 3);
                if (parts.length == 3) {
                    scores.add(new Score(parts[0], parts[1], Double.parseDouble(parts[2])));
                }
            }
        } catch (Exception e) {
            System.out.println("加载成绩信息失败：" + e.getMessage());
        }
    }
}
