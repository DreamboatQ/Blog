package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;
import model.*;

import service.ScoreService;

public class ScoreTableFrame extends JFrame {
    private final ScoreService service;

    public ScoreTableFrame(ScoreService service) {
        this.service = service;
        setTitle("学生成绩管理系统");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // 创建表格
        String[] columnNames = {"学生ID", "学生姓名", "课程ID", "课程名称", "成绩"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // 创建按钮
        JButton refreshButton = new JButton("刷新数据");
        refreshButton.addActionListener(e -> refreshTable(model));

        JButton avgButton = new JButton("显示平均分");
        avgButton.addActionListener(e -> service.printAverageScores());

        JButton chartButton = new JButton("显示图表");
        chartButton.addActionListener(e -> {
            Map<String, Double> avgMap = service.getAverageMap();
            SwingUtilities.invokeLater(() -> {
                new ScoreChartFrame(avgMap).setVisible(true);
            });
        });

        JButton saveButton = new JButton("保存数据");
        saveButton.addActionListener(e -> service.saveAll());

        // 按钮面板
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(refreshButton);
        buttonPanel.add(avgButton);
        buttonPanel.add(chartButton);
        buttonPanel.add(saveButton);

        // 添加组件
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // 初始加载数据
        refreshTable(model);

        add(mainPanel);
    }

    private void refreshTable(DefaultTableModel model) {
        model.setRowCount(0); // 清除现有数据

        for (Score score : service.scores) {
            model.addRow(new Object[]{
                    score.studentId,
                    service.getStudentName(score.studentId),
                    score.courseId,
                    service.getCourseName(score.courseId),
                    score.score
            });
        }
    }
}