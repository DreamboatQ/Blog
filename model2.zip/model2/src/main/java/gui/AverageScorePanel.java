package gui;

import model.*;
import service.ScoreService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AverageScorePanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public AverageScorePanel() {
        setLayout(new BorderLayout());

        // 表头
        String[] columnNames = {"学生姓名", "平均分"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        loadData();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void loadData() {
        List<Student> students = ScoreService.getInstance().students;
        List<Score> scores = ScoreService.getInstance().scores;

        // 计算每个学生的平均分
        for (Student student : students) {
            double total = 0;
            int count = 0;

            for (Score score : scores) {
                if (score.studentId.equals(student.id)) {
                    total += score.score;
                    count++;
                }
            }

            double avg = (count == 0) ? 0 : total / count;
            tableModel.addRow(new Object[]{student.name, String.format("%.2f", avg)});
        }
    }
}
