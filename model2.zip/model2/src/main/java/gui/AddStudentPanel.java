package gui;

import model.Student;
import service.ScoreService;

import javax.swing.*;
import java.awt.*;

public class AddStudentPanel extends JPanel {
    private JTextField idField;
    private JTextField nameField;
    private JButton addButton;

    public AddStudentPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel idLabel = new JLabel("学号：");
        JLabel nameLabel = new JLabel("姓名：");

        idField = new JTextField(15);
        nameField = new JTextField(15);
        addButton = new JButton("添加学生");

        gbc.insets = new Insets(5, 5, 5, 5); // 外边距
        gbc.gridx = 0; gbc.gridy = 0;
        add(idLabel, gbc);

        gbc.gridx = 1;
        add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(nameLabel, gbc);

        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(addButton, gbc);

        addButton.addActionListener(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();

            if (id.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "请输入学号和姓名！");
                return;
            }

            Student student = new Student(id, name);
            ScoreService.getInstance().addStudent(id,name);

            JOptionPane.showMessageDialog(this, "学生添加成功！");
            idField.setText("");
            nameField.setText("");
        });
    }
}
