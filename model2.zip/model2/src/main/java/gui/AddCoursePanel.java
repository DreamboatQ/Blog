package gui;

import service.ScoreService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AddCoursePanel extends JPanel {
    private JTextField courseIdField;
    private JTextField courseNameField;
    private JButton addButton;

    public AddCoursePanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel courseIdLabel = new JLabel("课程编号：");
        JLabel courseNameLabel = new JLabel("课程名称：");

        courseIdField = new JTextField(15);
        courseNameField = new JTextField(15);
        addButton = new JButton("添加课程");

        gbc.insets = new Insets(5, 5, 5, 5); // 外边距

        gbc.gridx = 0; gbc.gridy = 0;
        add(courseIdLabel, gbc);
        gbc.gridx = 1;
        add(courseIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(courseNameLabel, gbc);
        gbc.gridx = 1;
        add(courseNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(addButton, gbc);

        // 添加按钮的事件监听器
        addButton.addActionListener(this::addCourseAction);
    }

    private void addCourseAction(ActionEvent e) {
        String courseId = courseIdField.getText().trim();
        String courseName = courseNameField.getText().trim();

        if (courseId.isEmpty() || courseName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入课程编号和课程名称！");
            return;
        }

        // 调用 ScoreService 添加课程
        ScoreService.getInstance().addCourse(courseId, courseName);

        // 提示用户课程添加成功
        JOptionPane.showMessageDialog(this, "课程添加成功！");
        courseIdField.setText(""); // 清空输入框
        courseNameField.setText("");
    }
}
