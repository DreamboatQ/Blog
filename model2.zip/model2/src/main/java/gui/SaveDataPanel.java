package gui;

import service.ScoreService;

import javax.swing.*;
import java.awt.*;

public class SaveDataPanel extends JPanel {
    public SaveDataPanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("点击按钮保存数据");
        add(label, BorderLayout.NORTH);

        JButton saveButton = new JButton("保存数据");
        saveButton.addActionListener(e -> {
            ScoreService.getInstance().saveAll();
            JOptionPane.showMessageDialog(this, "数据已保存！");
        });
        add(saveButton, BorderLayout.CENTER);
    }
}
