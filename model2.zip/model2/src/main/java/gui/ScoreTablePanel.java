package gui;

import model.Score;
import model.Student;
import model.Course;
import service.ScoreService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ScoreTablePanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public ScoreTablePanel() {
        setLayout(new BorderLayout());

        // 表头
        String[] columnNames = {"学生姓名", "课程名称", "成绩"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        loadData();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void loadData() {
        List<Score> scores = ScoreService.getInstance().scores;
        List<Student> students = ScoreService.getInstance().students;
        List<Course> courses = ScoreService.getInstance().courses;

        for (Score score : scores) {
            String studentName = students.stream()
                    .filter(st -> st.id.equals(score.studentId))
                    .map(st -> st.name)
                    .findFirst().orElse("未知学生");

            String courseName = courses.stream()
                    .filter(c -> c.id.equals(score.courseId))
                    .map(c -> c.name)
                    .findFirst().orElse("未知课程");

            tableModel.addRow(new Object[]{studentName, courseName, score.score});
        }
    }
}
