package gui;

import service.ScoreService;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("学生成绩管理系统");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // 添加各个页面
        tabbedPane.addTab("添加学生", new AddStudentPanel());
        tabbedPane.addTab("添加课程", new AddCoursePanel()); // 添加课程面板
        tabbedPane.addTab("添加成绩", new AddScorePanel());
        tabbedPane.addTab("查看成绩表格", new ScoreTablePanel());
        tabbedPane.addTab("显示平均分", new AverageScorePanel());
        tabbedPane.addTab("显示图表", new ScoreChartPanel(ScoreService.getInstance().getAverageMap()));
        tabbedPane.addTab("保存数据", new SaveDataPanel());

        setContentPane(tabbedPane);
    }
}
