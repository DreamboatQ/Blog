package gui;

import service.ScoreService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AddScorePanel extends JPanel {
    private JTextField studentIdField;
    private JTextField courseIdField;
    private JTextField scoreField;
    private JButton addButton;

    public AddScorePanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel studentIdLabel = new JLabel("学生学号：");
        JLabel courseIdLabel = new JLabel("课程编号：");
        JLabel scoreLabel = new JLabel("成绩：");

        studentIdField = new JTextField(15);
        courseIdField = new JTextField(15);
        scoreField = new JTextField(15);
        addButton = new JButton("添加成绩");

        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        add(studentIdLabel, gbc);
        gbc.gridx = 1;
        add(studentIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(courseIdLabel, gbc);
        gbc.gridx = 1;
        add(courseIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(scoreLabel, gbc);
        gbc.gridx = 1;
        add(scoreField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(addButton, gbc);

        // 添加按钮的事件监听器
        addButton.addActionListener(this::addScoreAction);
    }

    private void addScoreAction(ActionEvent e) {
        String studentId = studentIdField.getText().trim();
        String courseId = courseIdField.getText().trim();
        String scoreText = scoreField.getText().trim();

        if (studentId.isEmpty() || courseId.isEmpty() || scoreText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请完整输入学号、课程编号和成绩！");
            return;
        }

        try {
            double score = Double.parseDouble(scoreText);

            // 调用 ScoreService 添加成绩
            ScoreService.getInstance().addScore(studentId, courseId, score);

            // 分数预警功能
            if (score < 60) {
                JOptionPane.showMessageDialog(this, "警告：" + studentId + " 的成绩低于 60 分！");
            }

            JOptionPane.showMessageDialog(this, "成绩添加成功！");
            studentIdField.setText("");
            courseIdField.setText("");
            scoreField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "成绩请输入数字！");
        }
    }
}
