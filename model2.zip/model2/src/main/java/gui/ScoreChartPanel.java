package gui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class ScoreChartPanel extends JPanel {
    public ScoreChartPanel(Map<String, Double> avgMap) {
        setLayout(new BorderLayout());

        // 创建数据集
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Double> entry : avgMap.entrySet()) {
            dataset.addValue(entry.getValue(), "平均分", entry.getKey());
        }

        // 创建图表
        JFreeChart chart = ChartFactory.createBarChart(
                "学生平均分柱状图",
                "学生姓名",
                "平均分",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        // 设置中文字体
        Font font = new Font("宋体", Font.PLAIN, 14);
        chart.getTitle().setFont(new Font("宋体", Font.BOLD, 18));
        chart.getLegend().setItemFont(font);

        CategoryPlot plot = chart.getCategoryPlot();
        plot.getDomainAxis().setTickLabelFont(font);
        plot.getDomainAxis().setLabelFont(font);
        plot.getRangeAxis().setTickLabelFont(font);
        plot.getRangeAxis().setLabelFont(font);

        // 添加图表到面板
        ChartPanel chartPanel = new ChartPanel(chart);
        add(chartPanel, BorderLayout.CENTER);
    }
}
