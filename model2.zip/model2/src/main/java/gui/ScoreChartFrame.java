package gui;
import org.jfree.chart.*;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ScoreChartFrame extends JFrame {
    public ScoreChartFrame(Map<String, Double> avgMap) {
        setTitle("学生平均成绩图表");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Double> entry : avgMap.entrySet()) {
            dataset.addValue(entry.getValue(), "平均分", entry.getKey());
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "学生平均分柱状图",
                "学生",
                "平均分",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false

        );
        // ✅ 设置中文字体防止乱码
        Font font = new Font("宋体", Font.PLAIN, 14);
        chart.getTitle().setFont(new Font("宋体", Font.BOLD, 18));  // 图表标题
        chart.getLegend().setItemFont(font);                        // 图例

        CategoryPlot plot = chart.getCategoryPlot();
        plot.getDomainAxis().setTickLabelFont(font);  // X轴标注
        plot.getDomainAxis().setLabelFont(font);      // X轴标题
        plot.getRangeAxis().setTickLabelFont(font);   // Y轴标注
        plot.getRangeAxis().setLabelFont(font);       // Y轴标题

        // 添加图表面板到窗口
        ChartPanel panel = new ChartPanel(chart);
        setContentPane(panel);
    }
}

