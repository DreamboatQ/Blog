import gui.ScoreChartFrame;
import service.ScoreService;

import javax.swing.*;
import java.util.Map;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
     ScoreService service=new ScoreService();
     Scanner sc=new Scanner(System.in);
     while(true){
         System.out.println("\n===学生成绩管理系统===");
         System.out.println("1.添加学生:");
         System.out.println("2.添加课程:");
         System.out.println("3.添加成绩:");
         System.out.println("4.查看成绩:");
         System.out.println("5.学生平均分统计:");
         System.out.println("6.图形化显示学生平均分:");
         System.out.println("0.退出");
         System.out.println("请输入操作：");

         int choice=sc.nextInt();
         sc.nextLine();

         switch (choice){
             case 1->{
                 System.out.print("学生ID：");
                 String sid=sc.nextLine();
                 System.out.print("学生姓名：");
                 String sname=sc.nextLine();
                 service.addStudent(sid,sname);
             }
             case 2->{
                 System.out.print("课程ID：");
                 String cid=sc.nextLine();
                 System.out.print("课程姓名：");
                 String cname=sc.nextLine();
                 service.addCourse(cid,cname);
             }
             case 3->{
                 System.out.print("学生ID：");
                 String sid=sc.nextLine();
                 System.out.print("课程ID：");
                 String cid=sc.nextLine();
                 System.out.print("分数：");
                 double score=sc.nextDouble();
                 sc.nextLine();
                 service.addScore(sid,cid,score);
             }
             case 4->service.printAllScores();
             case 5->service.printAverageScores();
             case 6->{
                 Map<String,Double>avgMap=service.getAverageMap();
                 SwingUtilities.invokeLater(()->{
                     new ScoreChartFrame(avgMap).setVisible(true);
                 });

             }
             case 0->{
                 System.out.println("退出系统");
                 return;
             }
             default ->  System.out.println("无效选项");
         }
      }
    }
}